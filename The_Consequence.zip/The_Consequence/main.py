
import pygame
import sys

from ui.menu import MainMenu
from ui.dialogue import DialogueBox
from ui.choice import ChoiceBox
from ui.status import StatusPanel
from ui.ending import EndingScreen

from states.game_state import GameState
from states.state_manager import StateManager
from states.save_manager import SaveManager
from states.story_manager import StoryManager


# =====================================
# KHOI TAO PYGAME
# =====================================
pygame.init()

SCREEN_WIDTH = 1000
SCREEN_HEIGHT = 600

screen = pygame.display.set_mode(
    (SCREEN_WIDTH, SCREEN_HEIGHT)
)

pygame.display.set_caption(
    "THE CONSEQUENCE - Light Novel"
)

clock = pygame.time.Clock()
FPS = 60


# =====================================
# KHOI TAO GIAO DIEN
# =====================================
main_menu = MainMenu(screen)
dialogue_box = DialogueBox(screen)
choice_box = ChoiceBox(screen)
status_panel = StatusPanel(screen)
ending_screen = EndingScreen(screen)


# =====================================
# KHOI TAO CAC HE THONG
# =====================================
game_state = GameState()
state_manager = StateManager()
save_manager = SaveManager()
story_manager = StoryManager()

dialogue_index = 0
ending_type = None


# =====================================
# LAY DU LIEU KICH BAN HIEN TAI
# =====================================
def get_story():

    return story_manager.get_current_story()


# =====================================
# XAC DINH ENDING
# =====================================
def determine_ending(stats):

    total = sum(stats.values())

    if stats["Trust"] <= -15 or stats["Outcome"] <= -15:
        return "bad"

    elif (
        total >= 20
        and stats["Trust"] >= 0
        and stats["Outcome"] >= 0
    ):
        return "good"

    else:
        return "normal"


# =====================================
# HIEN THI HOI THOAI
# =====================================
def show_intro_dialogue():

    global dialogue_index

    story = get_story()

    dialogue_index = 0

    dialogue_box.set_dialogue(
        story["intro"][dialogue_index][0],
        story["intro"][dialogue_index][1]
    )


# =====================================
# BAT DAU GAME MOI
# =====================================
def start_new_game():

    global game_state
    global ending_type

    game_state = GameState()

    ending_type = None

    story_manager.set_day(2)

    show_intro_dialogue()

    state_manager.change_state("dialogue")

    save_progress()


# =====================================
# LUU TIEN TRINH
# =====================================
def save_progress():

    current_state = state_manager.get_state()

    if current_state == "menu":
        return False

    data = {
        "stats": game_state.stats.copy(),
        "current_state": current_state,
        "current_day": story_manager.get_current_day(),
        "dialogue_index": dialogue_index,
        "ending_type": ending_type
    }

    if current_state in ["dialogue", "result"]:

        data["speaker"] = dialogue_box.speaker
        data["text"] = dialogue_box.text

    return save_manager.save(data)


# =====================================
# TAI TIEN TRINH
# =====================================
def load_progress():

    global game_state
    global dialogue_index
    global ending_type

    data = save_manager.load()

    if data is None:
        print("Khong co tien trinh de tai!")
        return False

    try:

        saved_stats = data["stats"]
        saved_state = data["current_state"]
        saved_day = data["current_day"]

        valid_states = [
            "dialogue",
            "choice",
            "result",
            "ending"
        ]

        if saved_state not in valid_states:
            return False

        required_stats = [
            "Empathy",
            "Professionalism",
            "Trust",
            "Outcome"
        ]

        if not all(key in saved_stats for key in required_stats):
            return False

        if not story_manager.set_day(saved_day):
            return False

        # Khoi phuc chi so
        game_state = GameState()
        game_state.stats.update(saved_stats)

        # Khoi phuc vi tri hoi thoai
        dialogue_index = data.get("dialogue_index", 0)

        if not isinstance(dialogue_index, int):
            return False

        ending_type = data.get("ending_type")

        # Khoi phuc giao dien
        if saved_state == "dialogue":

            story = get_story()

            if not 0 <= dialogue_index < len(story["intro"]):
                return False

            dialogue_box.set_dialogue(
                data["speaker"],
                data["text"]
            )

        elif saved_state == "choice":

            story = get_story()

            choice_box.set_choices(story["choices"])

        elif saved_state == "result":

            dialogue_box.set_dialogue(
                data["speaker"],
                data["text"]
            )

        elif saved_state == "ending":

            if ending_type not in ["good", "normal", "bad"]:
                return False

            ending_screen.set_ending(ending_type)

        state_manager.change_state(saved_state)

        game_state.show_stats()

        print("Tai tien trinh thanh cong!")

        return True

    except (KeyError, TypeError, ValueError) as error:

        print(f"Loi khi tai tien trinh: {error}")

        return False


# =====================================
# CHUYEN SANG NGAY TIEP THEO
# =====================================
def go_to_next_day():

    global ending_type

    if story_manager.next_day():

        print(
            "Bat dau ngay",
            story_manager.get_current_day()
        )

        show_intro_dialogue()

        state_manager.change_state("dialogue")

        save_progress()

    else:

        print("Da hoan thanh tat ca cac tinh huong!")

        ending_type = determine_ending(
            game_state.stats
        )

        ending_screen.set_ending(ending_type)

        state_manager.change_state("ending")

        save_progress()


# =====================================
# GAME LOOP
# =====================================
running = True

while running:

    # =================================
    # XU LY SU KIEN
    # =================================
    for event in pygame.event.get():

        if event.type == pygame.QUIT:

            save_progress()
            running = False

        # =================================
        # MAIN MENU
        # =================================
        elif state_manager.is_state("menu"):

            action = main_menu.handle_event(event)

            if action == "new_game":

                start_new_game()

            elif action == "continue":

                if save_manager.has_save():
                    load_progress()
                else:
                    print("Ban chua co tien trinh game!")

            elif action == "settings":

                print("Mo cai dat!")

            elif action == "quit":

                running = False

        # =================================
        # DIALOGUE
        # =================================
        elif state_manager.is_state("dialogue"):

            next_dialogue = dialogue_box.handle_event(event)

            if next_dialogue:

                story = get_story()

                dialogue_index += 1

                if dialogue_index < len(story["intro"]):

                    dialogue_box.set_dialogue(
                        story["intro"][dialogue_index][0],
                        story["intro"][dialogue_index][1]
                    )

                    save_progress()

                else:

                    choice_box.set_choices(
                        story["choices"]
                    )

                    state_manager.change_state("choice")

                    save_progress()

        # =================================
        # CHOICE
        # =================================
        elif state_manager.is_state("choice"):

            selected_choice = choice_box.handle_event(event)

            if selected_choice is not None:

                story = get_story()

                # Cap nhat chi so
                game_state.update_stats(
                    story["points"][selected_choice]
                )

                print(
                    "\nNgay:",
                    story_manager.get_current_day()
                )

                print(
                    "Lua chon:",
                    story["choices"][selected_choice]
                )

                game_state.show_stats()

                # Hien thi hoi thoai phan hoi
                dialogue_box.set_dialogue(
                    story["results"][selected_choice][0],
                    story["results"][selected_choice][1]
                )

                state_manager.change_state("result")

                save_progress()

        # =================================
        # RESULT
        # =================================
        elif state_manager.is_state("result"):

            next_dialogue = dialogue_box.handle_event(event)

            if next_dialogue:

                print(
                    "Ket thuc tinh huong ngay",
                    story_manager.get_current_day()
                )

                go_to_next_day()

        # =================================
        # ENDING
        # =================================
        elif state_manager.is_state("ending"):

            action = ending_screen.handle_event(event)

            if action == "menu":

                state_manager.reset()


    # =====================================
    # VE GIAO DIEN
    # =====================================

    if state_manager.is_state("menu"):

        main_menu.draw()

    elif state_manager.is_state("dialogue"):

        screen.fill((35, 42, 55))

        dialogue_box.draw()

        status_panel.draw(game_state.stats)

    elif state_manager.is_state("choice"):

        screen.fill((35, 42, 55))

        # Tieu de tinh huong
        story = get_story()

        title_font = pygame.font.SysFont(
            "Arial", 28, bold=True
        )

        title = title_font.render(
            story["title"],
            True,
            (245, 245, 245)
        )

        title_rect = title.get_rect(
            center=(SCREEN_WIDTH // 2, 180)
        )

        screen.blit(title, title_rect)

        # Ve cac lua chon
        choice_box.draw()

        # Hien thi chi so
        status_panel.draw(game_state.stats)

    elif state_manager.is_state("result"):

        screen.fill((35, 42, 55))

        dialogue_box.draw()

        status_panel.draw(game_state.stats)

    elif state_manager.is_state("ending"):

        ending_screen.draw()

    # =====================================
    # CAP NHAT MAN HINH
    # =====================================
    pygame.display.flip()

    clock.tick(FPS)


# =====================================
# KET THUC PYGAME
# =====================================
pygame.quit()
sys.exit()
