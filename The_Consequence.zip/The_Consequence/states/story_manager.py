
class StoryManager:

    def __init__(self):

        self.current_day = 2

        # Du lieu kich ban
        self.story = {

            2: {
                "title": "DAY 2 - REVIEW REPORT",

                "intro": [
                    (
                        "Lan",
                        "Minh oi, chi da hoan thanh ban bao cao roi. Em xem giup chi nhe."
                    ),
                    (
                        "Minh",
                        "Ban bao cao co mot so cho chua ro rang va mot vai so lieu can kiem tra lai."
                    ),
                    (
                        "Lan",
                        "Sao roi? Em thay on khong?"
                    )
                ],

                "choices": [
                    "A. Bao cao co qua nhieu loi. Chi lam viec thieu can than qua.",
                    "B. Bo cuc kha tot. Tuy nhien, co mot so so lieu can kiem tra lai.",
                    "C. U, cung duoc. Cu gui di, chac khong co van de gi dau."
                ],

                "results": [
                    (
                        "Lan",
                        "Chi chi muon em kiem tra giup thoi. Khong can phai noi nhu vay."
                    ),
                    (
                        "Lan",
                        "That a? Cam on em da kiem tra. Chung ta cung sua lai nhe!"
                    ),
                    (
                        "Lan",
                        "Vay minh gui cho anh Tuan nhe!"
                    )
                ],

                "points": [
                    {
                        "Empathy": -10,
                        "Professionalism": -5,
                        "Trust": -10,
                        "Outcome": -5
                    },
                    {
                        "Empathy": 10,
                        "Professionalism": 10,
                        "Trust": 10,
                        "Outcome": 10
                    },
                    {
                        "Empathy": 0,
                        "Professionalism": -10,
                        "Trust": -10,
                        "Outcome": -15
                    }
                ]
            },

            3: {
                "title": "DAY 3 - CUSTOMER SUPPORT",

                "intro": [
                    (
                        "Tuan",
                        "Minh, hom nay co mot khach hang dang rat buc xuc ve dich vu cua cong ty."
                    ),
                    (
                        "Tuan",
                        "Em hay thu trao doi va tim cach giai quyet van de nhe."
                    ),
                    (
                        "Minh",
                        "Vang, em se thu xu ly tinh huong nay."
                    )
                ],

                "choices": [
                    "A. Do la loi cua khach hang, cong ty khong the chiu trach nhiem.",
                    "B. Lang nghe khach hang va tim cach giai quyet van de.",
                    "C. Tra loi qua loa de ket thuc cuoc trao doi."
                ],

                "results": [
                    (
                        "Khach hang",
                        "Toi khong hai long voi cach giai thich nay!"
                    ),
                    (
                        "Khach hang",
                        "Cam on ban da lang nghe va ho tro toi."
                    ),
                    (
                        "Khach hang",
                        "Toi van chua nhan duoc cau tra loi ro rang."
                    )
                ],

                "points": [
                    {
                        "Empathy": -15,
                        "Professionalism": -10,
                        "Trust": -10,
                        "Outcome": -10
                    },
                    {
                        "Empathy": 10,
                        "Professionalism": 10,
                        "Trust": 10,
                        "Outcome": 10
                    },
                    {
                        "Empathy": -5,
                        "Professionalism": -15,
                        "Trust": -15,
                        "Outcome": -15
                    }
                ]
            },

            4: {
                "title": "DAY 4 - WORKLOAD",

                "intro": [
                    (
                        "Tuan",
                        "Minh, hien tai phong ban dang co rat nhieu cong viec can hoan thanh."
                    ),
                    (
                        "Tuan",
                        "Anh muon em ho tro them mot so nhiem vu."
                    ),
                    (
                        "Minh",
                        "Em nen xu ly tinh huong nay nhu the nao day?"
                    )
                ],

                "choices": [
                    "A. Tu choi thang thung vi khong muon nhan them viec.",
                    "B. Trao doi voi anh Tuan de sap xep thu tu uu tien.",
                    "C. Chap nhan tat ca cong viec du dang qua tai."
                ],

                "results": [
                    (
                        "Tuan",
                        "Anh that vong vi em khong co tinh than ho tro dong doi."
                    ),
                    (
                        "Tuan",
                        "Tot lam Minh. Chung ta se cung sap xep cong viec hop ly."
                    ),
                    (
                        "Tuan",
                        "Anh ghi nhan su co gang cua em, nhung em can biet sap xep cong viec."
                    )
                ],

                "points": [
                    {
                        "Empathy": -5,
                        "Professionalism": -10,
                        "Trust": -15,
                        "Outcome": -15
                    },
                    {
                        "Empathy": 5,
                        "Professionalism": 15,
                        "Trust": 10,
                        "Outcome": 10
                    },
                    {
                        "Empathy": 0,
                        "Professionalism": -10,
                        "Trust": -5,
                        "Outcome": -5
                    }
                ]
            }
        }

    def get_current_day(self):
        return self.current_day

    def get_current_story(self):
        return self.story.get(self.current_day)

    def next_day(self):

        if self.current_day < 4:

            self.current_day += 1

            return True

        return False

    def set_day(self, day):

        if day in self.story:

            self.current_day = day

            return True

        return False
