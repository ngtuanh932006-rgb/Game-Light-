
class StateManager:
    def __init__(self):
        # Trang thai ban dau cua game
        self.current_state = "menu"

        # Danh sach cac trang thai hop le
        self.states = [
            "menu",
            "dialogue",
            "choice",
            "result",
            "ending"
        ]

    def change_state(self, new_state):
        """Chuyen sang trang thai moi"""
        if new_state in self.states:
            self.current_state = new_state
            print(f"Game state changed to: {new_state}")
        else:
            print(f"Trang thai khong hop le: {new_state}")

    def is_state(self, state):
        """Kiem tra trang thai hien tai"""
        return self.current_state == state

    def get_state(self):
        """Lay trang thai hien tai"""
        return self.current_state

    def reset(self):
        """Quay lai trang thai ban dau"""
        self.current_state = "menu"
