class GameState:

    def __init__(self):

        # Cac chi so ban dau
        self.stats = {
            "Empathy": 0,
            "Professionalism": 0,
            "Trust": 0,
            "Outcome": 0
        }

    # Cap nhat chi so theo lua chon
    def update_stats(self, changes):

        for stat, value in changes.items():

            if stat in self.stats:
                self.stats[stat] += value

    # Hien thi cac chi so
    def show_stats(self):

        print("\n===== CHI SO HIEN TAI =====")

        for stat, value in self.stats.items():

            print(f"{stat}: {value}")

        print("===========================\n")