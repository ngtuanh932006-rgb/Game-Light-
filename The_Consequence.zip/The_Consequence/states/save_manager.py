
import json
import os


class SaveManager:

    def __init__(self):
        self.save_file = "save_data.json"

    def save(self, data):
        """Luu tien trinh game vao file JSON"""

        try:
            with open(self.save_file, "w", encoding="utf-8") as file:
                json.dump(data, file, ensure_ascii=False, indent=4)

            print("Da luu tien trinh game!")

            return True

        except (OSError, TypeError, ValueError) as error:
            print(f"Loi khi luu game: {error}")
            return False

    def load(self):
        """Doc tien trinh game tu file JSON"""

        if not os.path.exists(self.save_file):
            print("Khong tim thay file save!")
            return None

        try:
            with open(self.save_file, "r", encoding="utf-8") as file:
                data = json.load(file)

            print("Da tai tien trinh game!")

            return data

        except (OSError, json.JSONDecodeError) as error:
            print(f"Loi khi tai game: {error}")
            return None

    def has_save(self):
        """Kiem tra co file save hay chua"""

        return os.path.exists(self.save_file)

    def delete_save(self):
        """Xoa tien trinh game"""

        if os.path.exists(self.save_file):
            os.remove(self.save_file)
            print("Da xoa tien trinh game!")
