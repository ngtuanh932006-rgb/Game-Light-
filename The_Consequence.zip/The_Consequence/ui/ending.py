import pygame


class EndingScreen:

    def __init__(self, screen):

        self.screen = screen

        self.width = screen.get_width()
        self.height = screen.get_height()

        self.title_font = pygame.font.SysFont(
            "Arial", 42, bold=True
        )

        self.subtitle_font = pygame.font.SysFont(
            "Arial", 25, bold=True
        )

        self.content_font = pygame.font.SysFont(
            "Arial", 21
        )

        self.button_font = pygame.font.SysFont(
            "Arial", 23, bold=True
        )

        self.WHITE = (245, 245, 245)
        self.GRAY = (185, 190, 200)
        self.BOX_COLOR = (25, 35, 52)
        self.BUTTON_COLOR = (35, 48, 70)
        self.HOVER_COLOR = (65, 90, 125)
        self.BORDER_COLOR = (130, 155, 185)

        self.ending_title = ""
        self.ending_subtitle = ""
        self.ending_content = []

        self.button_rect = pygame.Rect(
            self.width // 2 - 140,
            490,
            280,
            55
        )

    # Thiet lap noi dung Ending
    def set_ending(self, ending_type):

        if ending_type == "good":

            self.ending_title = "THE IDEAL EMPLOYEE"
            self.ending_subtitle = "KET THUC TOT - NHAN VIEN LY TUONG"

            self.ending_content = [
                "Minh duoc danh gia tich cuc sau tuan thu viec.",
                "Dong nghiep tin tuong va san sang hop tac.",
                "Tuan nhin nhan Minh la mot nhan vien co tiem nang.",
                "Minh duoc tiep tuc lam viec tai Rebound Corporation."
            ]

        elif ending_type == "normal":

            self.ending_title = "THE ORDINARY EMPLOYEE"
            self.ending_subtitle = "KET THUC BINH THUONG"

            self.ending_content = [
                "Minh van duoc tiep tuc lam viec tai cong ty.",
                "Tuan danh gia Minh o muc trung binh.",
                "Minh chua tao duoc su tin tuong manh me.",
                "Minh can cai thien ky nang giao tiep va xu ly tinh huong."
            ]

        elif ending_type == "bad":

            self.ending_title = "LOST TRUST"
            self.ending_subtitle = "KET THUC XAU - MAT LONG TIN"

            self.ending_content = [
                "Minh khong vuot qua tuan thu viec.",
                "Tuan mat niem tin vao kha nang lam viec cua Minh.",
                "Moi quan he voi dong nghiep khong duoc xay dung tot.",
                "Minh phai roi khoi Rebound Corporation."
            ]

    # Ve giao dien Ending
    def draw(self):

        self.screen.fill((20, 27, 43))

        # Tieu de
        title = self.title_font.render(
            self.ending_title,
            True,
            self.WHITE
        )

        title_rect = title.get_rect(
            center=(self.width // 2, 110)
        )

        self.screen.blit(title, title_rect)

        # Phu de
        subtitle = self.subtitle_font.render(
            self.ending_subtitle,
            True,
            self.GRAY
        )

        subtitle_rect = subtitle.get_rect(
            center=(self.width // 2, 175)
        )

        self.screen.blit(subtitle, subtitle_rect)

        # Khung noi dung
        content_rect = pygame.Rect(
            100, 220, self.width - 200, 230
        )

        pygame.draw.rect(
            self.screen,
            self.BOX_COLOR,
            content_rect,
            border_radius=12
        )

        pygame.draw.rect(
            self.screen,
            self.BORDER_COLOR,
            content_rect,
            width=2,
            border_radius=12
        )

        # Noi dung ket thuc
        y = 255

        for line in self.ending_content:

            text = self.content_font.render(
                "- " + line,
                True,
                self.WHITE
            )

            self.screen.blit(
                text,
                (content_rect.x + 25, y)
            )

            y += 42

        # Nut quay lai Menu
        mouse_pos = pygame.mouse.get_pos()

        if self.button_rect.collidepoint(mouse_pos):
            color = self.HOVER_COLOR
        else:
            color = self.BUTTON_COLOR

        pygame.draw.rect(
            self.screen,
            color,
            self.button_rect,
            border_radius=10
        )

        pygame.draw.rect(
            self.screen,
            self.BORDER_COLOR,
            self.button_rect,
            width=2,
            border_radius=10
        )

        button_text = self.button_font.render(
            "BACK TO MENU",
            True,
            self.WHITE
        )

        button_text_rect = button_text.get_rect(
            center=self.button_rect.center
        )

        self.screen.blit(
            button_text,
            button_text_rect
        )

    # Xu ly su kien
    def handle_event(self, event):

        if event.type == pygame.MOUSEBUTTONDOWN:

            if event.button == 1:

                if self.button_rect.collidepoint(event.pos):
                    return "menu"

        return None