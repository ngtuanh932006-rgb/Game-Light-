
import pygame


class MainMenu:

    def __init__(self, screen):

        self.screen = screen

        # Kich thuoc man hinh
        self.width = screen.get_width()
        self.height = screen.get_height()

        # Font chu
        self.title_font = pygame.font.SysFont(
            "Arial", 64, bold=True
        )

        self.subtitle_font = pygame.font.SysFont(
            "Arial", 22
        )

        self.button_font = pygame.font.SysFont(
            "Arial", 26, bold=True
        )

        # Mau sac
        self.WHITE = (245, 245, 245)
        self.GRAY = (170, 175, 190)
        self.BUTTON_COLOR = (35, 48, 70)
        self.HOVER_COLOR = (65, 90, 125)
        self.BORDER_COLOR = (130, 155, 185)

        # Danh sach cac nut
        self.buttons = []

        button_names = [
            ("NEW GAME", "new_game"),
            ("CONTINUE", "continue"),
            ("SETTINGS", "settings"),
            ("QUIT GAME", "quit")
        ]

        button_width = 280
        button_height = 55

        start_y = 290
        spacing = 72

        for i, (name, action) in enumerate(button_names):

            rect = pygame.Rect(
                self.width // 2 - button_width // 2,
                start_y + i * spacing,
                button_width,
                button_height
            )

            self.buttons.append({
                "name": name,
                "action": action,
                "rect": rect
            })

    # Ve giao dien Main Menu
    def draw(self):

        # Mau nen
        self.screen.fill((20, 27, 43))

        # Ve cac duong trang tri
        pygame.draw.rect(
            self.screen,
            (30, 42, 62),
            (0, 0, self.width, 110)
        )

        # Tieu de game
        title = self.title_font.render(
            "THE CONSEQUENCE",
            True,
            self.WHITE
        )

        title_rect = title.get_rect(
            center=(self.width // 2, 125)
        )

        self.screen.blit(title, title_rect)

        # Phu de
        subtitle = self.subtitle_font.render(
            "A LIGHT NOVEL STORY",
            True,
            self.GRAY
        )

        subtitle_rect = subtitle.get_rect(
            center=(self.width // 2, 185)
        )

        self.screen.blit(subtitle, subtitle_rect)

        # Mo ta
        description = self.subtitle_font.render(
            "Every choice has its consequence.",
            True,
            self.GRAY
        )

        description_rect = description.get_rect(
            center=(self.width // 2, 235)
        )

        self.screen.blit(description, description_rect)

        # Ve cac nut
        mouse_pos = pygame.mouse.get_pos()

        for button in self.buttons:

            rect = button["rect"]

            # Kiem tra chuot co nam tren nut khong
            if rect.collidepoint(mouse_pos):
                color = self.HOVER_COLOR
            else:
                color = self.BUTTON_COLOR

            # Ve nen nut
            pygame.draw.rect(
                self.screen,
                color,
                rect,
                border_radius=10
            )

            # Ve vien nut
            pygame.draw.rect(
                self.screen,
                self.BORDER_COLOR,
                rect,
                width=2,
                border_radius=10
            )

            # Ve chu tren nut
            text = self.button_font.render(
                button["name"],
                True,
                self.WHITE
            )

            text_rect = text.get_rect(
                center=rect.center
            )

            self.screen.blit(text, text_rect)

        # Dong chu cuoi man hinh
        footer = self.subtitle_font.render(
            "REBOUND CORPORATION",
            True,
            (100, 110, 130)
        )

        footer_rect = footer.get_rect(
            center=(self.width // 2, 580)
        )

        self.screen.blit(footer, footer_rect)

    # Xu ly su kien chuot
    def handle_event(self, event):

        if event.type == pygame.MOUSEBUTTONDOWN:

            if event.button == 1:

                for button in self.buttons:

                    if button["rect"].collidepoint(event.pos):

                        return button["action"]

        return None
