import pygame


class StatusPanel:

    def __init__(self, screen):

        self.screen = screen

        self.font = pygame.font.SysFont(
            "Arial", 17, bold=True
        )

        self.title_font = pygame.font.SysFont(
            "Arial", 22, bold=True
        )

        self.value_font = pygame.font.SysFont(
            "Arial", 16
        )

        # Mau sac
        self.WHITE = (245, 245, 245)
        self.GRAY = (180, 185, 195)
        self.PANEL_COLOR = (20, 27, 43)
        self.BORDER_COLOR = (100, 125, 155)
        self.BAR_BG = (55, 65, 80)
        self.BAR_COLOR = (100, 175, 135)

        # Vi tri bang trang thai
        self.panel_rect = pygame.Rect(
            screen.get_width() - 275,
            20,
            255,
            205
        )

        # Ten cac chi so
        self.stat_names = [
            "Empathy",
            "Professionalism",
            "Trust",
            "Outcome"
        ]

    # Ve thanh trang thai
    def draw(self, stats):

        # Ve nen bang
        pygame.draw.rect(
            self.screen,
            self.PANEL_COLOR,
            self.panel_rect,
            border_radius=10
        )

        # Ve vien bang
        pygame.draw.rect(
            self.screen,
            self.BORDER_COLOR,
            self.panel_rect,
            width=2,
            border_radius=10
        )

        # Tieu de
        title = self.title_font.render(
            "MINH'S STATUS",
            True,
            self.WHITE
        )

        self.screen.blit(
            title,
            (self.panel_rect.x + 15,
             self.panel_rect.y + 12)
        )

        # Ve tung chi so
        start_y = self.panel_rect.y + 48

        for i, name in enumerate(self.stat_names):

            value = stats[name]

            # Ten chi so
            name_text = self.font.render(
                name,
                True,
                self.GRAY
            )

            self.screen.blit(
                name_text,
                (self.panel_rect.x + 15, start_y)
            )

            # Gia tri chi so
            value_text = self.value_font.render(
                f"{value:+}",
                True,
                self.WHITE
            )

            value_rect = value_text.get_rect(
                midright=(
                    self.panel_rect.right - 15,
                    start_y + 9
                )
            )

            self.screen.blit(
                value_text,
                value_rect
            )

            # Thanh hien thi chi so
            bar_rect = pygame.Rect(
                self.panel_rect.x + 15,
                start_y + 23,
                self.panel_rect.width - 30,
                9
            )

            pygame.draw.rect(
                self.screen,
                self.BAR_BG,
                bar_rect,
                border_radius=5
            )

            # Gioi han gia tri thanh tu -100 den 100
            normalized_value = max(
                -100,
                min(100, value)
            )

            fill_width = int(
                (normalized_value + 100) / 200
                * bar_rect.width
            )

            fill_rect = pygame.Rect(
                bar_rect.x,
                bar_rect.y,
                fill_width,
                bar_rect.height
            )

            pygame.draw.rect(
                self.screen,
                self.BAR_COLOR,
                fill_rect,
                border_radius=5
            )

            start_y += 38