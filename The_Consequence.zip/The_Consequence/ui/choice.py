import pygame


class ChoiceBox:

    def __init__(self, screen):

        self.screen = screen
        self.width = screen.get_width()
        self.height = screen.get_height()

        self.font = pygame.font.SysFont(
            "Arial", 21
        )

        self.WHITE = (245, 245, 245)
        self.BUTTON_COLOR = (35, 48, 70)
        self.HOVER_COLOR = (65, 90, 125)
        self.BORDER_COLOR = (130, 155, 185)

        self.choices = []
        self.choice_rects = []

    # Tao danh sach lua chon
    def set_choices(self, choices):

        self.choices = choices
        self.choice_rects = []

        button_width = self.width - 160
        button_height = 65
        start_y = 300
        spacing = 80

        for i, choice in enumerate(choices):

            rect = pygame.Rect(
                80,
                start_y + i * spacing,
                button_width,
                button_height
            )

            self.choice_rects.append(rect)

    # Ve cac nut lua chon
    def draw(self):

        mouse_pos = pygame.mouse.get_pos()

        for i, choice in enumerate(self.choices):

            rect = self.choice_rects[i]

            if rect.collidepoint(mouse_pos):
                color = self.HOVER_COLOR
            else:
                color = self.BUTTON_COLOR

            pygame.draw.rect(
                self.screen,
                color,
                rect,
                border_radius=10
            )

            pygame.draw.rect(
                self.screen,
                self.BORDER_COLOR,
                rect,
                width=2,
                border_radius=10
            )

            text = self.font.render(
                choice,
                True,
                self.WHITE
            )

            text_rect = text.get_rect(
                midleft=(rect.x + 20, rect.centery)
            )

            self.screen.blit(text, text_rect)

    # Xu ly su kien nhan chuot
    def handle_event(self, event):

        if event.type == pygame.MOUSEBUTTONDOWN:

            if event.button == 1:

                for i, rect in enumerate(self.choice_rects):

                    if rect.collidepoint(event.pos):
                        return i

        return None