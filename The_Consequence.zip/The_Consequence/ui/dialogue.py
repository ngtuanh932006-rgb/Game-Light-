import pygame


class DialogueBox:

    def __init__(self, screen):

        self.screen = screen
        self.width = screen.get_width()
        self.height = screen.get_height()

        # Font chu
        self.name_font = pygame.font.SysFont(
            "Arial", 25, bold=True
        )

        self.dialogue_font = pygame.font.SysFont(
            "Arial", 22
        )

        # Mau sac
        self.BOX_COLOR = (20, 27, 43)
        self.BORDER_COLOR = (130, 155, 185)
        self.WHITE = (245, 245, 245)
        self.NAME_COLOR = (150, 195, 235)
        self.GRAY = (170, 175, 190)

        # Noi dung hoi thoai
        self.speaker = ""
        self.text = ""

        # Khung hoi thoai
        self.dialogue_rect = pygame.Rect(
            50,
            self.height - 190,
            self.width - 100,
            160
        )

    # Cap nhat noi dung hoi thoai
    def set_dialogue(self, speaker, text):

        self.speaker = speaker
        self.text = text

    # Tu dong xuong dong khi loi thoai dai
    def wrap_text(self, text, font, max_width):

        words = text.split(" ")
        lines = []
        current_line = ""

        for word in words:

            test_line = current_line + word + " "

            if font.size(test_line)[0] <= max_width:
                current_line = test_line
            else:
                lines.append(current_line.strip())
                current_line = word + " "

        if current_line:
            lines.append(current_line.strip())

        return lines

    # Ve khung hoi thoai
    def draw(self):

        # Ve nen khung
        pygame.draw.rect(
            self.screen,
            self.BOX_COLOR,
            self.dialogue_rect,
            border_radius=12
        )

        # Ve vien khung
        pygame.draw.rect(
            self.screen,
            self.BORDER_COLOR,
            self.dialogue_rect,
            width=2,
            border_radius=12
        )

        # Ve ten nhan vat
        name_surface = self.name_font.render(
            self.speaker,
            True,
            self.NAME_COLOR
        )

        self.screen.blit(
            name_surface,
            (self.dialogue_rect.x + 25,
             self.dialogue_rect.y + 18)
        )

        # Ve noi dung loi thoai
        lines = self.wrap_text(
            self.text,
            self.dialogue_font,
            self.dialogue_rect.width - 50
        )

        y = self.dialogue_rect.y + 60

        for line in lines:

            text_surface = self.dialogue_font.render(
                line,
                True,
                self.WHITE
            )

            self.screen.blit(
                text_surface,
                (self.dialogue_rect.x + 25, y)
            )

            y += 30

        # Huong dan nguoi choi
        hint = self.dialogue_font.render(
            "Click chuot hoac nhan SPACE de tiep tuc",
            True,
            self.GRAY
        )

        hint_rect = hint.get_rect(
            bottomright=(
                self.dialogue_rect.right - 20,
                self.dialogue_rect.bottom - 12
            )
        )

        self.screen.blit(hint, hint_rect)

    # Xu ly su kien chuyen loi thoai
    def handle_event(self, event):

        if event.type == pygame.MOUSEBUTTONDOWN:
            if event.button == 1:
                return True

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_SPACE:
                return True

        return False