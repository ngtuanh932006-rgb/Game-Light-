THE CONSEQUENCE - BẢN SỬA FONT VÀ HIỂN THỊ CHỮ

1. Giải nén toàn bộ ZIP, không chạy file Python trực tiếp bên trong ZIP.
2. Giữ nguyên thư mục the_consequence_assets cạnh file the_consequence.py.
3. Cài Pygame:
   python -m pip install --upgrade pygame
4. Chạy:
   python the_consequence.py

SỬA LỖI CHỮ:
- Dùng Noto Sans làm font chính và DejaVu Sans làm font dự phòng.
- Chuẩn hóa Unicode NFC để dấu tiếng Việt không bị tách hoặc hiển thị sai.
- Tự xuống dòng, kể cả từ dài không có khoảng trắng.
- Tự giảm cỡ chữ khi câu thoại dài để hạn chế bị cắt.
- Font được đóng gói sẵn; không cần cài font vào Windows.

LƯU Ý:
- Không xóa thư mục the_consequence_assets/fonts.
- Nếu vẫn thấy chữ lỗi, hãy gửi ảnh chụp màn hình và tên màn hình/đoạn hội thoại.

HUD FIX: Story and choice HUD text is now rendered only once at native resolution. This removes doubled company title, duplicated stat counters, and overlapping keyboard hints.
